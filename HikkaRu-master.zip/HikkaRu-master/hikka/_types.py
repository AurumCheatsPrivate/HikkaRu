import logging
from telethon.tl.types import Message


class Module:
    strings = {"name": "Unknown"}

    """Для этого модуля нет никакой помощи"""

    def config_complete(self):
        """Будет вызван при заполнении module.config"""

    async def client_ready(self, client, db):
        """Будет вызван после того, как клиент будет готов (после config_loaded)"""

    async def on_unload(self):
        """Будет вызван после выгрузки / перезагрузки модуля"""

    # Called after client_ready, for internal use only. Must not be used by non-core modules
    async def _client_ready2(self, client, db):
        pass


class LoadError(Exception):
    def __init__(self, error_message: str):  # skipcq: PYL-W0231
        self._error = error_message

    def __str__(self) -> str:
        return self._error


class StopLoop(Exception):
    """Останавливает цикл, в котором поднимается"""


class ModuleConfig(dict):
    """Как dict, но содержит doc для каждого ключа"""

    def __init__(self, *entries):
        keys = []
        values = []
        defaults = []
        docstrings = []
        for i, entry in enumerate(entries):
            if i % 3 == 0:
                keys.append(entry)
            elif i % 3 == 1:
                values.append(entry)
                defaults.append(entry)
            else:
                docstrings.append(entry)

        super().__init__(zip(keys, values))
        self._docstrings = dict(zip(keys, docstrings))
        self._defaults = dict(zip(keys, defaults))

    def getdoc(self, key: str, message: Message = None) -> str:
        """Получить документацию по ключу"""
        ret = self._docstrings[key]
        if callable(ret):
            try:
                ret = ret(message)
            except TypeError:  # Invalid number of params
                logging.debug(f"{key} использование устаревших документов trnsl")
                ret = ret()

        return ret

    def getdef(self, key: str) -> str:
        """Получить значение по умолчанию с помощью ключа"""
        return self._defaults[key]
