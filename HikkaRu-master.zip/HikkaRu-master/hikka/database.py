# █ █ ▀ █▄▀ ▄▀█ █▀█ ▀    ▄▀█ ▀█▀ ▄▀█ █▀▄▀█ ▄▀█
# █▀█ █ █ █ █▀█ █▀▄ █ ▄  █▀█  █  █▀█ █ ▀ █ █▀█
#
#              © Copyright 2022
#
#          https://t.me/hikariatama
#
# 🔒 Licensed under the GNU GPLv3
# 🌐 https://www.gnu.org/licenses/agpl-3.0.html
# Перевёл: @SpYHC


import asyncio
import logging

from telethon.tl.functions.channels import CreateChannelRequest
from telethon.tl.types import Message, Channel
import json
import os
from typing import Any, Union

from . import utils

DATA_DIR = (
    os.path.normpath(os.path.join(utils.get_base_dir(), ".."))
    if "OKTETO" not in os.environ
    else "/data"
)

logger = logging.getLogger(__name__)


def is_serializable(x: Any, /) -> bool:
    """Проверяет, является ли объект сериализуемым в формате JSON"""
    try:
        json.dumps(x)
        return True
    except (TypeError, OverflowError):
        return False


class Database(dict):
    def __init__(self, client):
        super().__init__()
        self._client = client
        self._me = None
        self._assets = None
        self._anti_double_asset_lock = asyncio.Lock()
        self._assets_chat_exists = False

    def __repr__(self):
        return object.__repr__(self)

    async def init(self):
        """Блок асинхронной инициализации"""
        self._me = await self._client.get_me()
        self._db_path = os.path.join(DATA_DIR, f"config-{self._me.id}.json")
        self.read()

    async def _find_asset_channel(self) -> Channel:
        """Найдите канал активов и верните его одноранговый узел"""
        async for dialog in self._client.iter_dialogs(None, ignore_migrated=True):
            if dialog.name == f"hikka-{self._me.id}-assets" and dialog.is_channel:

                if dialog.entity.participants_count != 1:
                    continue

                logger.debug(f"Чат найденных активов {dialog.id}")
                return dialog.entity

    async def _make_asset_channel(self) -> Channel:
        """Если у пользователя нет канала ресурсов, создайте его"""
        async with self._anti_double_asset_lock:
            if self._assets_chat_exists:
                return await self._find_asset_channel()
            self._assets_chat_exists = True

            dialog = (
                await self._client(
                    CreateChannelRequest(
                        f"hikka-{self._me.id}-assets",
                        "🌆 Ваши активы HikkaRu будут храниться здесь",
                        megagroup=True,
                    )
                )
            ).chats[0]

            await self._client.edit_folder(dialog, folder=1)

            return dialog

    def read(self) -> str:
        """Чтение базы данных"""
        try:
            with open(self._db_path, "r", encoding="utf-8") as f:
                data = json.loads(f.read())
                self.update(**data)
                return data
        except (FileNotFoundError, json.decoder.JSONDecodeError):
            logger.exception("Ошибка чтения базы данных! Создание нового...")
            return {}

    def save(self) -> bool:
        """Сохранить базу данных"""
        try:
            with open(self._db_path, "w", encoding="utf-8") as f:
                f.write(json.dumps(self))
        except Exception:
            logger.exception("Не удалось сохранить базу данных!")
            return False

        return True

    async def store_asset(self, message: Message) -> int:
        """
        Сохранить активы
        возвращает asset_id как целое число
        """
        if not self._assets:
            self._assets = await self._find_asset_channel()

        if not self._assets:
            self._assets = await self._make_asset_channel()

        return (
            (await self._client.send_message(self._assets, message)).id
            if isinstance(message, Message)
            else (
                await self._client.send_message(
                    self._assets,
                    file=message,
                    force_document=True,
                )
            ).id
        )

    async def fetch_asset(self, asset_id: int) -> Union[None, Message]:
        """Извлекать ранее сохраненный актив по его asset_id"""
        if not self._assets:
            self._assets = await self._find_asset_channel()

        if not self._assets:
            return None

        asset = await self._client.get_messages(self._assets, ids=[asset_id])

        if not asset:
            return None

        return asset[0]

    def get(self, owner: str, key: str, default: Any = None) -> Any:
        """Получить ключ базы данных"""
        try:
            return self[owner][key]
        except KeyError:
            return default

    def set(self, owner: str, key: str, value: Any) -> bool:
        """Установить ключ базы данных"""
        if not is_serializable(owner):
            raise RuntimeError(
                "Предпринята попытка записать объект в "
                f"{type(owner)=} из базы данных. Это не "
                "JSON-сериализуемый ключ, который приведет к ошибкам"
            )

        if not is_serializable(key):
            raise RuntimeError(
                "Предпринята попытка записать объект в "
                f"{type(key)=} базы данных. Это не так "
                "JSON-сериализуемый ключ, который вызовет ошибки"
            )

        if not is_serializable(value):
            raise RuntimeError(
                "Попытался записать объект из "
                f"{type(value)=} в базу данных. Это не так "
                "JSON-сериализуемое значение, которое приведет к ошибкам"
            )

        super().setdefault(owner, {})[key] = value
        return self.save()
