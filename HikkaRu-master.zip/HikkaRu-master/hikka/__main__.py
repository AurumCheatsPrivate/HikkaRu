"""Entry point. Checks for user and starts main script"""

#    Friendly Telegram (telegram userbot)
#    Copyright (C) 2018-2021 The Authors

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.

#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <https://www.gnu.org/licenses/>.

# █ █ ▀ █▄▀ ▄▀█ █▀█ ▀    ▄▀█ ▀█▀ ▄▀█ █▀▄▀█ ▄▀█
# █▀█ █ █ █ █▀█ █▀▄ █ ▄  █▀█  █  █▀█ █ ▀ █ █▀█
#
#              © Copyright 2022
#
#          https://t.me/hikariatama
#
# 🔒 Licensed under the GNU GPLv3
# 🌐 https://www.gnu.org/licenses/agpl-3.0.HTML
# Перевёл: @SpYHC

import sys
import getpass
import os
import subprocess
import atexit

if (
    getpass.getuser() == "root"
    and "--root" not in " ".join(sys.argv)
    and "OKTETO" not in os.environ
):
    print("🚫" * 30)
    print("НИКОГДА НЕ ЗАПУСКАЙТЕ USERBOT ИЗ ROOT")
    print("ЭТО ПОТОК НЕ ТОЛЬКО ДЛЯ ВАШИХ ДАННЫХ, ")
    print("НО ТАКЖЕ И ДЛЯ САМОГО ВАШЕГО УСТРОЙСТВА!")
    print("🚫" * 30)
    print()
    print("ВВЕДИТЕ force_insecure, ЧТОБЫ ПРОИГНОРИРОВАТЬ ЭТО ПРЕДУПРЕЖДЕНИЕ")
    print("ВВЕДИТЕ ЧТО-НИБУДЬ ЕЩЕ, ЧТОБЫ ВЫЙТИ:")
    if input("> ").lower() != "force_insecure":
        sys.exit(1)


def deps(error):
    print(
        "🚫 Ошибка: вы неправильно установили все зависимости.\n"
        f"{str(error)}\n"
        "🔄 Попытка установки зависимостей... Просто подожди ⏱"
    )

    subprocess.run(
        [
            sys.executable,
            "-m",
            "pip",
            "install",
            "--upgrade",
            "-q",
            "--disable-pip-version-check",
            "--no-warn-script-location",
            "-r",
            "requirements.txt",
        ],
        check=True,
    )

    restart()


def restart():
    if "HIKKA_DO_NOT_RESTART" in os.environ:
        print("Попал в петлю, выходя")
        sys.exit(0)

    print("🔄 Перезапуск...")

    atexit.register(
        lambda: os.execl(
            sys.executable,
            sys.executable,
            "-m",
            os.path.relpath(
                os.path.abspath(
                    os.path.dirname(
                        os.path.abspath(__file__),
                    ),
                ),
            ),
            *(sys.argv[1:]),
        )
    )

    os.environ["HIKKA_DO_NOT_RESTART"] = "1"

    sys.exit(0)


if sys.version_info < (3, 8, 0):
    print("🚫 Ошибка: вы должны использовать по крайней мере Python версии 3.8.0")
elif __package__ != "hikka":  # In case they did python __main__.py
    print("🚫 Ошибка: вы не можете запустить это как скрипт; вы должны выполнить как пакет")  # fmt: skip
else:
    try:
        import telethon  # noqa: F401
    except Exception:
        pass
    else:
        try:
            from telethon.tl.functions.messages import SendReactionRequest  # noqa: F401
        except ImportError:
            print("⚠️ Предупреждение: Телемарафон по умолчанию используется в качестве основного. Это может привести к ошибкам и включить DAR. Попытка переустановить telethon-mod...") # fmt: пропустить
            subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "pip",
                    "uninstall",
                    "-y",
                    "telethon",
                ],
                check=True,
            )

            subprocess.run(
                [
                    sys.executable,
                    "-m",
                    "pip",
                    "install",
                    "-U",
                    "-q",
                    "--disable-pip-version-check",
                    "--no-warn-script-location",
                    "telethon-mod",
                ],
                check=True,
            )

            restart()

    try:
        from . import log

        log.init()

        from . import main
    except ModuleNotFoundError as e:  # pragma: no cover
        deps(e)
        sys.exit(1)

    if __name__ == "__main__":
        if "HIKKA_DO_NOT_RESTART" in os.environ:
            del os.environ["HIKKA_DO_NOT_RESTART"]

        main.hikka.main()  # Execute main function
