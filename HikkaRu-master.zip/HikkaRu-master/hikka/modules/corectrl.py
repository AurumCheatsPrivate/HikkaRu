#    Friendly Telegram (telegram userbot)
#    Copyright (C) 2018-2021 The Authors

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.

#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <https://www.gnu.org/licenses/>.

# █ █ ▀ █▄▀ ▄▀█ █▀█ ▀    ▄▀█ ▀█▀ ▄▀█ █▀▄▀█ ▄▀█
# █▀█ █ █ █ █▀█ █▀▄ █ ▄  █▀█  █  █▀█ █ ▀ █ █▀█
#
#              © Copyright 2022
#
#          https://t.me/hikariatama
#
# 🔒 Licensed under the GNU GPLv3
# 🌐 https://www.gnu.org/licenses/agpl-3.0.HTML
# Перевёл: @SpYHC

from telethon.tl.types import Message

from .. import loader, main, utils, translations
import os


@loader.tds
class CoreMod(loader.Module):
    """Управление основными настройками пользовательского бота"""

    strings = {
        "name": "Settings",
        "too_many_args": "🚫 <b>Слишком много аргументов</b>",
        "blacklisted": "✅ <b>Чат {} внесен в черный список из пользовательского бота</b>",
        "unblacklisted": "✅ <b>Чат {} разблокирован из пользовательского бота</b>",
        "user_blacklisted": "✅ <b>Пользователь {} внесен в черный список userbot</b>",
        "user_unblacklisted": "✅ <b>Пользователь {} разблокирован из пользовательского бота</b>",
        "what_prefix": "❓ <b>На что должен быть установлен префикс?</b>",
        "prefix_incorrect": "🚫 <b>Длина префикса должна составлять один символ</b>",
        "prefix_set": "✅ <b>Обновлен командный префикс. Тип</b> <code>{newprefix}setprefix {oldprefix}</code> <b>чтобы изменить его обратно</b>",
        "alias_created": "✅ <b>Создан псевдоним. Получите доступ к нему с помощью</b> <code>{}</code>",
        "aliases": "<b>Псевдонимы:</b>\n",
        "no_command": "🚫 <b>Команда</b> <code>{}</code> <b>не существует</b>",
        "alias_args": "🚫 <b>Вы должны указать команду и псевдоним для нее</b>",
        "delalias_args": "🚫 <b>Вы должны указать псевдонимное имя</b>",
        "alias_removed": "✅ <b>Псевдоним</b> <code>{}</code> <b>удаленный.",
        "no_alias": "<b>🚫 Псевдоним</b> <code>{}</code> <b>не существует</b>",
        "db_cleared": "<b>✅ База данных очищена</b>",
        "hikka": "😈 <b>HikkaRu userbot</b>\n<b>Версия: {}.{}.{}</b>",
        "check_url": "🚫 <b>Вам необходимо указать действительный URL-адрес, содержащий langpack</b>",
        "lang_saved": "✅ <b>Язык сохранен!</b>",
        "pack_saved": "✅ <b>Пакет переводов сохранен!</b>",
        "incorrect_language": "🚫 <b>Указан неверный язык</b>",
        "lang_removed": "✅ <b>Переводы сбрасываются на переводы по умолчанию</b>",
        "check_pack": "🚫 <b>Недопустимый формат пакета в URL-адресе</b>",
    }

    async def client_ready(self, client, db):
        self._db = db
        self._client = client

    async def blacklistcommon(self, message: Message):
        args = utils.get_args(message)

        if len(args) > 2:
            await utils.answer(message, self.strings("too_many_args"))
            return

        chatid = None
        module = None

        if args:
            try:
                chatid = int(args[0])
            except ValueError:
                module = args[0]

        if len(args) == 2:
            module = args[1]

        if chatid is None:
            chatid = utils.get_chat_id(message)

        module = self.allmodules.get_classname(module)
        return f"{str(chatid)}.{module}" if module else chatid

    async def hikkacmd(self, message: Message):
        """Получить версию HikkaRu"""
        ver = main.__version__
        await utils.answer(message, self.strings("hikka").format(*ver))

    async def blacklistcmd(self, message: Message):
        """Внесите бота в черный список, чтобы он не работал где-либо"""
        chatid = await self.blacklistcommon(message)

        self._db.set(
            main.__name__,
            "blacklist_chats",
            self._db.get(main.__name__, "blacklist_chats", []) + [chatid],
        )

        await utils.answer(message, self.strings("blacklisted").format(chatid))

    async def unblacklistcmd(self, message: Message):
        """Разблокируйте список ботов, которые где-то работают"""
        chatid = await self.blacklistcommon(message)

        self._db.set(
            main.__name__,
            "blacklist_chats",
            list(
                set(self._db.get(main.__name__, "blacklist_chats", [])) - set([chatid])
            ),
        )

        await utils.answer(
            message, self.strings("unblacklisted").format(chatid)
        )

    async def getuser(self, message: Message):
        try:
            return int(utils.get_args(message)[0])
        except (ValueError, IndexError):
            reply = await message.get_reply_message()

            if reply:
                return (await message.get_reply_message()).sender_id

            if message.is_private:
                return message.to_id.user_id

            await utils.answer(message, self.strings("who_to_unblacklist"))
            return

    async def blacklistusercmd(self, message: Message):
        """Запретить этому пользователю выполнять какие-либо команды"""
        user = await self.getuser(message)

        self._db.set(
            main.__name__,
            "blacklist_users",
            self._db.get(main.__name__, "blacklist_users", []) + [user],
        )

        await utils.answer(
            message, self.strings("user_blacklisted").format(user)
        )

    async def unblacklistusercmd(self, message: Message):
        """Разрешить этому пользователю выполнять разрешенные команды"""
        user = await self.getuser(message)

        self._db.set(
            main.__name__,
            "blacklist_users",
            list(set(self._db.get(main.__name__, "blacklist_users", [])) - set([user])),  # skipcq: PTC-W0018
        )

        await utils.answer(
            message,
            self.strings("user_unblacklisted").format(user),
        )

    @loader.owner
    async def setprefixcmd(self, message: Message):
        """Устанавливает префикс команды"""
        args = utils.get_args_raw(message)

        if not args:
            await utils.answer(message, self.strings("what_prefix"))
            return

        if len(args) != 1:
            await utils.answer(message, self.strings("prefix_incorrect"))
            return

        oldprefix = self._db.get(main.__name__, "command_prefix", ".")
        self._db.set(main.__name__, "command_prefix", args)
        await utils.answer(
            message,
            self.strings("prefix_set").format(
                newprefix=utils.escape_html(args[0]),
                oldprefix=utils.escape_html(oldprefix),
            ),
        )

    @loader.owner
    async def aliasescmd(self, message: Message):
        """Выведите все ваши псевдонимы"""
        aliases = self.allmodules.aliases
        string = self.strings("aliases")

        string += "\n".join([f"\n{i}: {y}" for i, y in aliases.items()])

        await utils.answer(message, string)

    @loader.owner
    async def addaliascmd(self, message: Message):
        """Задайте псевдоним для команды"""
        args = utils.get_args(message)

        if len(args) != 2:
            await utils.answer(message, self.strings("alias_args"))
            return

        alias, cmd = args
        ret = self.allmodules.add_alias(alias, cmd)

        if ret:
            self._db.set(
                __name__,
                "aliases",
                {
                    **self._db.get(__name__, "aliases"),
                    alias: cmd,
                },
            )
            await utils.answer(
                message,
                self.strings("alias_created").format(utils.escape_html(alias)),
            )
        else:
            await utils.answer(
                message,
                self.strings("no_command").format(utils.escape_html(cmd)),
            )

    @loader.owner
    async def delaliascmd(self, message: Message):
        """Удаление псевдонима для команды"""
        args = utils.get_args(message)

        if len(args) != 1:
            await utils.answer(message, self.strings("delalias_args"))
            return

        alias = args[0]
        ret = self.allmodules.remove_alias(alias)

        if ret:
            current = self._db.get(__name__, "aliases")
            del current[alias]
            self._db.set(__name__, "aliases", current)
            await utils.answer(
                message,
                self.strings("alias_removed").format(utils.escape_html(alias)),
            )
        else:
            await utils.answer(
                message,
                self.strings("no_alias").format(utils.escape_html(alias)),
            )

    async def dllangpackcmd(self, message: Message):
        """[ссылка на langpack | пустой для удаления] - Изменить пакет перевода HikkaRu (внешний)"""
        args = utils.get_args_raw(message)

        if not args:
            self._db.set(translations.__name__, "pack", False)
            await self.translator.init()
            await utils.answer(message, self.strings("lang_removed"))
            return

        if not utils.check_url(args):
            await utils.answer(message, self.strings("check_url"))
            return

        self._db.set(translations.__name__, "pack", args)
        success = await self.translator.init()
        await utils.answer(message, self.strings("pack_saved" if success else "check_pack"))

    async def setlangcmd(self, message: Message):
        """[язык] - Изменить язык по умолчанию"""
        args = utils.get_args_raw(message)
        if not args or len(args) != 2:
            await utils.answer(message, self.strings("incorrect_language"))
            return

        possible_pack_path = os.path.join(
            utils.get_base_dir(),
            f"langpacks/{args.lower()}.json",
        )

        if os.path.isfile(possible_pack_path):
            self._db.set(translations.__name__, "pack", args.lower())

        self._db.set(translations.__name__, "lang", args.lower())
        await self.translator.init()
        await utils.answer(message, self.strings("lang_saved"))

    @loader.owner
    async def cleardbcmd(self, message: Message):
        """Очищает всю базу данных, эффективно выполняя сброс к заводским настройкам"""
        self._db.clear()
        self._db.save()
        await utils.answer(message, self.strings("db_cleared"))

    async def _client_ready2(self, client, db):  # skicpq: PYL-W0613
        ret = {
            alias: cmd
            for alias, cmd in db.get(__name__, "aliases", {}).items()
            if self.allmodules.add_alias(alias, cmd)
        }

        db.set(__name__, "aliases", ret)
