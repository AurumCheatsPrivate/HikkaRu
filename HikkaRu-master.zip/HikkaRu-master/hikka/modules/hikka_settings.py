# █ █ ▀ █▄▀ ▄▀█ █▀█ ▀    ▄▀█ ▀█▀ ▄▀█ █▀▄▀█ ▄▀█
# █▀█ █ █ █ █▀█ █▀▄ █ ▄  █▀█  █  █▀█ █ ▀ █ █▀█
#
#              © Copyright 2022
#
#          https://t.me/hikariatama
#
# 🔒 Licensed under the GNU GPLv3
# 🌐 https://www.gnu.org/licenses/agpl-3.0.html

# scope: inline

from .. import loader, utils, main
from telethon.tl.types import Message
from aiogram.types import CallbackQuery
import logging

logger = logging.getLogger(__name__)


@loader.tds
class HikkaSettingsMod(loader.Module):
    """Advanced settings for Hikka Userbot"""

    strings = {
        "name": "HikkaSettings",
        "watchers": "👀 <b>Наблюдатели:</b>\n\n<b>{}</b>",
        "mod404": "🚫 <b>Наблюдатель {} не найден</b>",
        "disabled": "👀 <b>Наблюдатель {} теперь <u>отключен</u></b>",
        "enabled": "👀 <b>Наблюдатель {} теперь включен <u></u></b>",
        "args": "🚫 <b>Вам необходимо указать имя наблюдателя</b>",
        "user_nn": "🔰 <b>NoNick для этого пользователя теперь {}</b>",
        "no_cmd": "🔰 <b>Пожалуйста, укажите команду для переключения NoNick для</b>",
        "cmd_nn": "🔰 <b>NoNick для </b><code>{}</code><b> теперь {}</b>",
        "cmd404": "🔰 <b>Команда не найдена</b>",
        "inline_settings": "⚙️ <b>Здесь вы можете настроить свои настройки HikkaRu</b>",
        "confirm_update": "🪂 <b>Пожалуйста, подтвердите, что вы хотите обновить. Ваш пользователь будет перезапущен</b>",
        "confirm_restart": "🔄 <b>Пожалуйста, подтвердите, что вы хотите перезапустить</b>",
        "suggest_fs": "✅ Предложите FS для модулей",
        "do_not_suggest_fs": "🚫 Предложите FS для модулей",
        "use_fs": "✅ Всегда используйте FS для модулей",
        "do_not_use_fs": "🚫 Всегда используйте FS для модулей",
        "btn_restart": "🔄 Перезапуск",
        "btn_update": "🪂 Обновление",
        "close_menu": "😌 Закрыть меню",
        "download_btn": "✅ Скачать с помощью кнопки",
        "no_download_btn": "🚫 Скачать с помощью кнопки",
        "private_not_allowed": "🚫 <b>Эта команда должна быть выполнена в чате</b>",
    }

    def get_watchers(self) -> tuple:
        return [
            str(_.__self__.__class__.strings["name"])
            for _ in self.allmodules.watchers
            if _.__self__.__class__.strings is not None
        ], self._db.get(main.__name__, "disabled_watchers", {})

    async def client_ready(self, client, db):
        self._db = db
        self._client = client

    async def watcherscmd(self, message: Message):
        """Список текущих наблюдателей"""
        watchers, disabled_watchers = self.get_watchers()
        watchers = [
            f"♻️ {_}" for _ in watchers if _ not in list(disabled_watchers.keys())
        ]
        watchers += [f"💢 {k} {v}" for k, v in disabled_watchers.items()]
        await utils.answer(
            message, self.strings("watchers").format("\n".join(watchers))
        )

    async def watcherblcmd(self, message: Message):
        """<модуль> - Переключение наблюдателя в текущем чате"""
        args = utils.get_args_raw(message)
        if not args:
            return await utils.answer(message, self.strings("args"))

        watchers, disabled_watchers = self.get_watchers()

        if args.lower() not in [_.lower() for _ in watchers]:
            return await utils.answer(message, self.strings("mod404").format(args))

        args = [_ for _ in watchers if _.lower() == args.lower()][0]

        current_bl = [
            v for k, v in disabled_watchers.items() if k.lower() == args.lower()
        ]
        current_bl = current_bl[0] if current_bl else []

        chat = utils.get_chat_id(message)
        if chat not in current_bl:
            if args in disabled_watchers:
                for k, _ in disabled_watchers.items():
                    if k.lower() == args.lower():
                        disabled_watchers[k].append(chat)
                        break
            else:
                disabled_watchers[args] = [chat]

            await utils.answer(
                message,
                self.strings("disabled").format(args) + " <b>в текущем чате</b>",
            )
        else:
            for k in disabled_watchers.copy():
                if k.lower() == args.lower():
                    disabled_watchers[k].remove(chat)
                    if not disabled_watchers[k]:
                        del disabled_watchers[k]
                    break

            await utils.answer(
                message,
                self.strings("enabled").format(args) + " <b>in current chat</b>",
            )

        self._db.set(main.__name__, "disabled_watchers", disabled_watchers)

    async def watchercmd(self, message: Message):
        """<модуль> - Переключение глобальных правил наблюдателя
        Аргументы:
        [-c - только в чатах]
        [-p - только в личку]
        [-o - только выход]
        [-i - только входящий]<module> - Toggle global watcher rules
        """
        args = utils.get_args_raw(message)
        if not args:
            return await utils.answer(message, self.strings("args"))

        chats, pm, out, incoming = False, False, False, False

        if "-c" in args:
            args = args.replace("-c", "").replace("  ", " ").strip()
            chats = True

        if "-p" in args:
            args = args.replace("-p", "").replace("  ", " ").strip()
            pm = True

        if "-o" in args:
            args = args.replace("-o", "").replace("  ", " ").strip()
            out = True

        if "-i" in args:
            args = args.replace("-i", "").replace("  ", " ").strip()
            incoming = True

        if chats and pm:
            pm = False
        if out and incoming:
            incoming = False

        watchers, disabled_watchers = self.get_watchers()

        if args.lower() not in [_.lower() for _ in watchers]:
            return await utils.answer(message, self.strings("mod404").format(args))

        args = [_ for _ in watchers if _.lower() == args.lower()][0]

        if chats or pm or out or incoming:
            disabled_watchers[args] = [
                *(["only_chats"] if chats else []),
                *(["only_pm"] if pm else []),
                *(["out"] if out else []),
                *(["in"] if incoming else []),
            ]
            self._db.set(main.__name__, "disabled_watchers", disabled_watchers)
            await utils.answer(
                message,
                self.strings("enabled").format(args)
                + f" (<code>{disabled_watchers[args]}</code>)",
            )
            return

        if args in disabled_watchers and "*" in disabled_watchers[args]:
            await utils.answer(message, self.strings("enabled").format(args))
            del disabled_watchers[args]
            self._db.set(main.__name__, "disabled_watchers", disabled_watchers)
            return

        disabled_watchers[args] = ["*"]
        self._db.set(main.__name__, "disabled_watchers", disabled_watchers)
        await utils.answer(message, self.strings("disabled").format(args))

    async def nonickusercmd(self, message: Message):
        """Разрешить не использовать псевдоним для определенного пользователя"""
        reply = await message.get_reply_message()
        u = reply.sender_id
        if not isinstance(u, int):
            u = u.user_id

        nn = self._db.get(main.__name__, "nonickusers", [])
        if u not in nn:
            nn += [u]
            nn = list(set(nn))  # skipcq: PTC-W0018
            await utils.answer(message, self.strings("user_nn").format("on"))
        else:
            nn = list(set(nn) - set([u]))  # skipcq: PTC-W0018
            await utils.answer(message, self.strings("user_nn").format("off"))

        self._db.set(main.__name__, "nonickusers", nn)

    async def nonickchatcmd(self, message: Message):
        """Разрешить не использовать ник в определенном чате"""
        if message.is_private:
            await utils.answer(message, self.strings("private_not_allowed"))
            return

        chat = utils.get_chat_id(message)

        nn = self._db.get(main.__name__, "nonickchats", [])
        if chat not in nn:
            nn += [chat]
            nn = list(set(nn))  # skipcq: PTC-W0018
            await utils.answer(
                message,
                self.strings("cmd_nn").format(
                    utils.escape_html((await message.get_chat()).title),
                    "on",
                ),
            )
        else:
            nn = list(set(nn) - set([chat]))  # skipcq: PTC-W0018
            await utils.answer(
                message,
                self.strings("cmd_nn").format(
                    utils.escape_html((await message.get_chat()).title),
                    "off",
                ),
            )

        self._db.set(main.__name__, "nonickchats", nn)

    async def nonickcmdcmd(self, message: Message):
        """Разрешить выполнение определенной команды без псевдонима"""
        args = utils.get_args_raw(message)
        if not args:
            return await utils.answer(message, self.strings("no_cmd"))

        if args not in self.allmodules.commands:
            return await utils.answer(message, self.strings("cmd404"))

        nn = self._db.get(main.__name__, "nonickcmds", [])
        if args not in nn:
            nn += [args]
            nn = list(set(nn))
            await utils.answer(
                message,
                self.strings("cmd_nn").format(
                    self._db.get(main.__name__, "command_prefix", ".") + args, "on"
                ),
            )
        else:
            nn = list(set(nn) - set([args]))  # skipcq: PTC-W0018
            await utils.answer(
                message,
                self.strings("cmd_nn").format(
                    self._db.get(main.__name__, "command_prefix", ".") + args,
                    "off",
                ),
            )

        self._db.set(main.__name__, "nonickcmds", nn)

    async def inline__setting(self, call: CallbackQuery, key: str, state: bool):
        self._db.set(main.__name__, key, state)

        if (
            key == "no_nickname"
            and state
            and self._db.get(main.__name__, "command_prefix", ".") == "."
        ):
            await call.answer(
                "Предупреждение! Вы включили NoNick с префиксом по умолчанию! "
                "Вы можете быть отключены в чатах HikkaRu. Изменить префикс или "
                "отключи NoNick!",
                show_alert=True,
            )
        else:
            await call.answer("Значение конфигурации сохранено!")

        await call.edit(
            self.strings("inline_settings"),
            reply_markup=self._get_settings_markup(),
        )

    async def inline__close(self, call: CallbackQuery):
        await call.delete()

    async def inline__update(
        self,
        call: CallbackQuery,
        confirm_required: bool = False,
    ):
        if confirm_required:
            await call.edit(
                self.strings("confirm_update"),
                reply_markup=[
                    {"text": "🪂 Обновление", "callback": self.inline__update},
                    {"text": "🚫 Отменить", "callback": self.inline__close},
                ],
            )
            return

        await call.answer("Ваш пользователь обновляется...", show_alert=True)
        await call.delete()
        m = await self._client.send_message("me", ".update")
        await self.allmodules.commands["update"](m)

    async def inline__restart(
        self,
        call: CallbackQuery,
        confirm_required: bool = False,
    ):
        if confirm_required:
            await call.edit(
                self.strings("confirm_restart"),
                reply_markup=[
                    {"text": "🔄 Перезапуск", "callback": self.inline__restart},
                    {"text": "🚫 Отменить", "callback": self.inline__close},
                ],
            )
            return

        await call.answer("Ваш пользовательский бот перезапускается...", show_alert=True)
        await call.delete()
        m = await self._client.send_message("me", ".restart")
        await self.allmodules.commands["restart"](m)

    def _get_settings_markup(self) -> list:
        return [
            [
                (
                    {
                        "text": "✅ NoNick",
                        "callback": self.inline__setting,
                        "args": (
                            "no_nickname",
                            False,
                        ),
                    }
                    if self._db.get(main.__name__, "no_nickname", False)
                    else {
                        "text": "🚫 NoNick",
                        "callback": self.inline__setting,
                        "args": (
                            "no_nickname",
                            True,
                        ),
                    }
                ),
                (
                    {
                        "text": "✅ Grep",
                        "callback": self.inline__setting,
                        "args": (
                            "grep",
                            False,
                        ),
                    }
                    if self._db.get(main.__name__, "grep", False)
                    else {
                        "text": "🚫 Grep",
                        "callback": self.inline__setting,
                        "args": (
                            "grep",
                            True,
                        ),
                    }
                ),
                (
                    {
                        "text": "✅ InlineLogs",
                        "callback": self.inline__setting,
                        "args": (
                            "inlinelogs",
                            False,
                        ),
                    }
                    if self._db.get(main.__name__, "inlinelogs", True)
                    else {
                        "text": "🚫 InlineLogs",
                        "callback": self.inline__setting,
                        "args": (
                            "inlinelogs",
                            True,
                        ),
                    }
                ),
            ],
            [
                (
                    {
                        "text": self.strings("suggest_fs"),
                        "callback": self.inline__setting,
                        "args": (
                            "disable_modules_fs",
                            True,
                        ),
                    }
                    if not self._db.get(main.__name__, "disable_modules_fs", False)
                    else {
                        "text": self.strings("do_not_suggest_fs"),
                        "callback": self.inline__setting,
                        "args": (
                            "disable_modules_fs",
                            False,
                        ),
                    }
                ),
            ],
            [
                (
                    {
                        "text": self.strings("use_fs"),
                        "callback": self.inline__setting,
                        "args": (
                            "permanent_modules_fs",
                            False,
                        ),
                    }
                    if self._db.get(main.__name__, "permanent_modules_fs", False)
                    else {
                        "text": self.strings("do_not_use_fs"),
                        "callback": self.inline__setting,
                        "args": (
                            "permanent_modules_fs",
                            True,
                        ),
                    }
                ),
            ],
            [
                (
                    {
                        "text": self.strings("download_btn"),
                        "callback": self.inline__setting,
                        "args": (
                            "use_dl_btn",
                            False,
                        ),
                    }
                    if self._db.get(main.__name__, "use_dl_btn", True)
                    else {
                        "text": self.strings("no_download_btn"),
                        "callback": self.inline__setting,
                        "args": (
                            "use_dl_btn",
                            True,
                        ),
                    }
                ),
            ],
            [
                {
                    "text": self.strings("btn_restart"),
                    "callback": self.inline__restart,
                    "args": (True,),
                },
                {
                    "text": self.strings("btn_update"),
                    "callback": self.inline__update,
                    "args": (True,),
                },
            ],
            [{"text": self.strings("close_menu"), "callback": self.inline__close}],
        ]

    @loader.owner
    async def settingscmd(self, message: Message):
        """Показать меню настроек"""
        await self.inline.form(
            self.strings("inline_settings"),
            message=message,
            reply_markup=self._get_settings_markup(),
        )
